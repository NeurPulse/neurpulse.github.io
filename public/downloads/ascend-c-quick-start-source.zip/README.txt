Ascend C SIMD quick-start examples from Huawei asc-devkit
Commit: e6dc42b66218e322567c26aa71b00bb39adbb79c
Source: https://gitcode.com/cann/asc-devkit/tree/e6dc42b66218e322567c26aa71b00bb39adbb79c

hello-world/hello_world.asc <- examples/01_simd_cpp_api/00_introduction/00_quickstart/hello_world/hello_world.asc
hello-world/CMakeLists.txt <- examples/01_simd_cpp_api/00_introduction/00_quickstart/hello_world/CMakeLists.txt
c-add/c_api_add.asc <- examples/02_simd_c_api/00_introduction/01_add/c_api_async_add/c_api_add.asc
c-add/CMakeLists.txt <- examples/02_simd_c_api/00_introduction/01_add/c_api_async_add/CMakeLists.txt
cpp-add/add.asc <- examples/01_simd_cpp_api/00_introduction/01_add/add/add.asc
cpp-add/CMakeLists.txt <- examples/01_simd_cpp_api/00_introduction/01_add/add/CMakeLists.txt

All .asc and CMakeLists.txt files are unchanged. See LICENSE for the full terms.
Build notes: https://neurpulse.github.io/notes/ascend-c-quick-start-environment/
