Ascend C SIMT quick-start examples from Huawei asc-devkit
Commit: e6dc42b66218e322567c26aa71b00bb39adbb79c
Source: https://gitcode.com/cann/asc-devkit/tree/e6dc42b66218e322567c26aa71b00bb39adbb79c

hello-world/hello_world.asc <- examples/03_simt_api/00_introduction/00_quickstart/hello_world_simt/hello_world.asc
hello-world/CMakeLists.txt <- examples/03_simt_api/00_introduction/00_quickstart/hello_world_simt/CMakeLists.txt
gather-1d/gather_1d.asc <- examples/03_simt_api/00_introduction/01_gather/basic_gather/gather_1d/gather_1d.asc
gather-1d/CMakeLists.txt <- examples/03_simt_api/00_introduction/01_gather/basic_gather/gather_1d/CMakeLists.txt

The .asc and CMakeLists.txt files are unchanged. See LICENSE for the full terms.
The upstream sample READMEs specify Ascend 950PR/950DT (dav-3510) and CANN 9.1.0 or later.
Follow the source directory links above for the original build instructions.
