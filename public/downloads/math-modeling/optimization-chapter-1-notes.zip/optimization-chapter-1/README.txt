最优化方法第一章独立学习笔记

先用支持数学公式的 Markdown 阅读器打开 notes.md，例如 Typora。
assets 文件夹包含四张配图，请与 notes.md 放在同一目录下。
笔记正文、公式和配图均在包内；代码仅使用 Python 标准库。
在本文件夹运行：python optimization-chapter-1-checks.py

在线阅读：
https://neurpulse.github.io/notes/mathematical-modeling-optimization-introduction/

内容包括课本概念、数学基础、五个例题、六道课后习题、
完整推导、15 道自测及答案、计算检查与复习卡片。
